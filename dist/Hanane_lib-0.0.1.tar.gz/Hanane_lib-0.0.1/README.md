Hanane Lib - Proclame la bonne parole
=====================================
Vive A2H


Vous pouvez l'installer avec pip:

    pip install Hanane_lib

Exemple d'usage:

    >>> from Hanane_lib import proclamer
    >>> proclamer()

Ce code est sous licence WTFPL.
